# NEXGUARD Android — Phase 1
এই source package-এ আছে Android app foundation, Supabase email/password login, Contacts/Microphone/Location/Notification runtime permission flow, one-time server-issued connection code, basic battery/network telemetry, Supabase schema, Edge Function এবং GitHub Actions APK workflow।

## Setup
1. Supabase SQL Editor-এ `supabase/migrations/001_phase1.sql` চালাও।
2. `supabase/functions/issue-device-code/index.ts` deploy করো।
3. Edge Function secrets: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`।
4. `android/app/build.gradle.kts`-এ Supabase URL ও publishable/anon key বসাও। Service-role key কখনো APK-তে বসাবে না।
5. এই ZIP-এর `android`, `supabase`, `.github` folders GitHub repo-র root-এ upload করো।
6. GitHub → Actions → Android APK Build → Run workflow. সফল হলে Artifacts-এ APK থাকবে।

## Phase 1-এ যা এখনো নেই
Location tracking, voice recording, contacts export, file transfer, website code-claim UI এবং Android Enterprise Device Owner enrollment এখনো implement হয়নি। Permission prompt দেখানো মানেই এই sensitive data সংগ্রহ/পাঠানো নয়। এগুলো পরের ধাপে আলাদা consent UI, foreground indicator, secure backend ও testing-সহ যুক্ত হবে।
