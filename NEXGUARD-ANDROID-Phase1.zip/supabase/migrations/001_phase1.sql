create table if not exists public.device_pairing_codes (
 id uuid primary key default gen_random_uuid(),
 code_hash text unique not null,
 owner_id uuid not null references auth.users(id) on delete cascade,
 device_name text not null,
 expires_at timestamptz not null,
 used_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.device_telemetry (
 id bigint generated always as identity primary key,
 owner_id uuid not null references auth.users(id) on delete cascade,
 battery_percent integer not null check (battery_percent between -1 and 100),
 is_charging boolean not null,
 network_type text not null,
 created_at timestamptz not null default now()
);
alter table public.device_pairing_codes enable row level security;
alter table public.device_telemetry enable row level security;
revoke all on public.device_pairing_codes from anon, authenticated;
revoke all on public.device_telemetry from anon;
grant insert,select on public.device_telemetry to authenticated;
create policy "user inserts own telemetry" on public.device_telemetry for insert to authenticated with check(auth.uid()=owner_id);
create policy "user reads own telemetry" on public.device_telemetry for select to authenticated using(auth.uid()=owner_id);
