import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 if(req.method!=="POST") return Response.json({error:"Method not allowed"},{status:405,headers:cors});
 try{
  const auth=req.headers.get("Authorization"); if(!auth) return Response.json({error:"Sign in required"},{status:401,headers:cors});
  const url=Deno.env.get("SUPABASE_URL")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const uc=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:{user},error}=await uc.auth.getUser(); if(error||!user) return Response.json({error:"Invalid session"},{status:401,headers:cors});
  const input=await req.json().catch(()=>({})); const deviceName=String(input.device_name||"Android device").slice(0,120);
  const raw=Array.from(crypto.getRandomValues(new Uint8Array(5))).map(v=>v.toString(16).padStart(2,"0")).join("").toUpperCase();
  const digest=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(raw));
  const hash=[...new Uint8Array(digest)].map(v=>v.toString(16).padStart(2,"0")).join("");
  const admin=createClient(url,service);
  const {error:insertError}=await admin.from("device_pairing_codes").insert({code_hash:hash,owner_id:user.id,device_name:deviceName,expires_at:new Date(Date.now()+600000).toISOString()});
  if(insertError) return Response.json({error:"Could not issue code"},{status:500,headers:cors});
  return Response.json({code:raw,expires_in_seconds:600},{headers:cors});
 }catch{return Response.json({error:"Bad request"},{status:400,headers:cors});}
});
